
<?php

function calculateArea($width, $length)
{
    $area = $width * $length;
    return $area;
}

$width = 4;
$length = 2;

$result = calculateArea($width, $length);

echo "The area of a rectangle with a width of $width and $length is $result";

?>
