<!DOCTYPE html>
<html lang="en">

<head>
    <title>Lab 7a Q1</title>
</head>

<body>
    <?php
    $name = "Mavinesh Nambiar A/L Kannan";
    $matric_no = "CI250130";
    $course = "Bachelor's in Computer Science";
    $year_study = "3rd Year";
    $address = "No. 18, Jln Mas Merah 1, Tmn Mas Merah, Sungai Abong,84000, Muar, Johor";
    ?>
    <table border="1" cellpadding="10">
        <tr>
            <td>Name</td>
            <td><?php echo $name; ?></td>
        </tr>

        <tr>
            <td>Matric Number</td>
            <td><?php echo $matric_no; ?></td>
        </tr>

        <tr>
            <td>Course</td>
            <td><?php echo $course; ?></td>
        </tr>

        <tr>
            <td>Year of Study</td>
            <td><?php echo $year_study; ?></td>
        </tr>

        <tr>
            <td>Address</td>
            <td><?php echo $address; ?></td>
        </tr>
    </table>
</body>

</html>